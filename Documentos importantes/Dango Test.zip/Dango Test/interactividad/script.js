document.addEventListener('DOMContentLoaded', function() {
    var coloresSuaves = ['#b1d3e2', '#4c9dbd', '#c9baa6']; // Lista de colores suaves

    function obtenerColorAleatorio() {
        var indiceAleatorio = Math.floor(Math.random() * coloresSuaves.length);
        return coloresSuaves[indiceAleatorio];
    }

    document.getElementById('changeColor').addEventListener('click', function() {
        var contenedores = document.querySelectorAll('.contenedor-superior');
        contenedores.forEach(function(contenedor) {
            contenedor.style.backgroundColor = obtenerColorAleatorio();
        });
        
        // Cambia el título a "Title Changes"
        document.querySelectorAll('.titulo-contenedor-interno').forEach(function(titulo) {
            titulo.textContent = "Title Changes";
        });
    });

    // Función para agregar una nueva tarjeta
    document.getElementById('addCard').addEventListener('click', function() {
        var contenedorTotal = document.querySelector('.contenedor-total');
        var nuevaTarjeta = document.querySelector('.contenedor-principal').cloneNode(true);
        contenedorTotal.appendChild(nuevaTarjeta);
    });

    // Función para eliminar una tarjeta
    document.getElementById('removeCard').addEventListener('click', function() {
        var contenedorTotal = document.querySelector('.contenedor-total');
        var ultimaTarjeta = contenedorTotal.lastElementChild;
        if (ultimaTarjeta) {
            contenedorTotal.removeChild(ultimaTarjeta);
        }
    });
});


